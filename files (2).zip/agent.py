"""
agent.py - AI helper for Game 11.

Answers player questions about coins, bets, winnings, matches,
and how the app works. It can only READ data. It cannot change anything.
"""
import os
import json

import anthropic

from models import User, Bet, WalletTransaction

MODEL = "claude-sonnet-5-5"
MAX_ROUNDS = 5  # the AI can use tools up to 5 times per question

# ---------------------------------------------------------------
# Step A: the "rule book". The AI reads this before every answer.
# ---------------------------------------------------------------
RULE_BOOK = """You are the helper inside Game 11, a cricket practice-betting app.
You talk to one logged-in player at a time.

How the app works:
- Players use virtual coins. Coins have NO real money value.
- A new player starts with 1000 coins.
- On the Wallet page, a player can refill 500, 1000 or 2000 coins for free.
- The Home page shows today's cricket matches. Each match has two teams.
- Right now the odds are 2.0 for both teams.
- A player can bet only when a match shows "Betting Open". This is only
  before the match starts. When a match is live or finished, betting is closed.
- To bet, the player picks a team and a stake (a whole number of coins).
  The stake cannot be more than the coins the player has. The stake is taken
  from the wallet right away.
- Potential winnings = stake x odds.
- A bet is "pending" until the match is settled. Then it becomes "won" or
  "lost". A "refunded" bet means the stake was given back.
- The match Leaderboard unlocks only after the player bets on that match.
  It ranks bets on that match by winnings.
- All match times are in IST (India time).
- The My Bets page shows all bets. The Wallet page shows refills and spending.

How to answer:
- Use very simple English. Use short sentences. No hard words.
- For anything about the player's coins, bets, winnings, or matches,
  ALWAYS use a tool first. Never guess numbers.
- If a bet is still pending, say it is not settled yet. Do not guess the result.
- A bet only has a match id. If you cannot find the match name, just say the id.
- You can only look at data. You cannot place bets, add coins, or change
  anything. If the player asks for that, tell them which page to use.
- If you do not know something, say so. Do not make things up.
- Never talk about other players' accounts or coins.
"""

# ---------------------------------------------------------------
# Step B: the tools. The AI can ask your app to run these.
# ---------------------------------------------------------------
TOOLS = [
    {
        "name": "get_my_balance",
        "description": "Get the coin balance of the player who is asking.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_my_bets",
        "description": (
            "Get the bets of the player who is asking, newest first. "
            "Also gives totals: total bets, total staked, total winnings. "
            "Each bet has match_id, team_picked, stake, odds, status "
            "(pending/won/lost/refunded) and winnings."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "limit": {
                    "type": "integer",
                    "description": "How many bets to return (1 to 20). Default 5.",
                },
                "match_id": {
                    "type": "string",
                    "description": "Only bets on this match. Leave empty for all.",
                },
            },
        },
    },
    {
        "name": "get_wallet_history",
        "description": (
            "Get the latest wallet refills and the latest coins spent on bets "
            "for the player who is asking."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "get_todays_matches",
        "description": (
            "Get today's matches: teams, status, start time (IST), venue, "
            "odds, and whether betting is open."
        ),
        "input_schema": {"type": "object", "properties": {}},
    },
]


def _clamp(value, low, high):
    try:
        value = int(value)
    except (TypeError, ValueError):
        value = low
    return max(low, min(high, value))


# ---------------------------------------------------------------
# Step C: the code that runs when the AI asks for a tool.
# user_id comes from the login session, NOT from the AI.
# So a player can never see another player's data.
# ---------------------------------------------------------------
def _get_my_balance(user_id):
    user = User.query.get(user_id)
    if not user:
        return {"error": "User not found"}
    return {"coins": user.coins}


def _get_my_bets(user_id, args):
    limit = _clamp(args.get("limit", 5), 1, 20)

    query = Bet.query.filter_by(user_id=user_id)
    match_id = args.get("match_id")
    if match_id:
        query = query.filter_by(match_id=str(match_id))
    all_bets = query.order_by(Bet.id.desc()).all()

    total_staked = sum(b.stake for b in all_bets)
    total_winnings = sum((b.winnings or 0) for b in all_bets if b.status == "won")

    bets = []
    for b in all_bets[:limit]:
        bets.append(
            {
                "match_id": b.match_id,
                "team_picked": b.team_picked,
                "stake": b.stake,
                "odds": b.odds,
                "status": b.status,
                "winnings": b.winnings or 0,
                "potential_winnings": round(b.stake * b.odds),
            }
        )

    return {
        "total_bets": len(all_bets),
        "total_staked": total_staked,
        "total_winnings": total_winnings,
        "bets": bets,
    }


def _get_wallet_history(user_id):
    refills = (
        WalletTransaction.query.filter_by(user_id=user_id, type="refill")
        .order_by(WalletTransaction.id.desc())
        .limit(10)
        .all()
    )
    spends = (
        Bet.query.filter_by(user_id=user_id)
        .order_by(Bet.id.desc())
        .limit(10)
        .all()
    )
    return {
        "latest_refills": [{"coins_added": t.amount} for t in refills],
        "latest_spends_on_bets": [
            {"match_id": b.match_id, "team_picked": b.team_picked, "coins_spent": b.stake}
            for b in spends
        ],
    }


def _get_todays_matches(get_matches):
    matches = get_matches()[:15]
    return [
        {
            "match_id": m["match_id"],
            "league": m["format"],
            "teams": f'{m["team1"]["name"]} vs {m["team2"]["name"]}',
            "status": m["status"],
            "start_time_ist": m["match_time"],
            "venue": m["venue"],
            "odds": {
                m["team1"]["name"]: m["team1"]["odds"],
                m["team2"]["name"]: m["team2"]["odds"],
            },
            "betting_open": m["betting_open"],
        }
        for m in matches
    ]


def run_tool(name, args, user_id, get_matches):
    if name == "get_my_balance":
        return _get_my_balance(user_id)
    if name == "get_my_bets":
        return _get_my_bets(user_id, args)
    if name == "get_wallet_history":
        return _get_wallet_history(user_id)
    if name == "get_todays_matches":
        return _get_todays_matches(get_matches)
    return {"error": "Unknown tool"}


# ---------------------------------------------------------------
# Step D: the loop.
# Ask the AI -> if it wants a tool, run it -> ask again -> final answer.
# ---------------------------------------------------------------
def ask_agent(user_id, question, get_matches):
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        return "The helper is not set up yet. Please try again later."

    client = anthropic.Anthropic(api_key=api_key)
    messages = [{"role": "user", "content": question}]

    for _ in range(MAX_ROUNDS):
        resp = client.messages.create(
            model=MODEL,
            max_tokens=600,
            system=RULE_BOOK,
            tools=TOOLS,
            messages=messages,
        )

        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text")

        messages.append({"role": "assistant", "content": resp.content})

        results = []
        for block in resp.content:
            if block.type == "tool_use":
                output = run_tool(block.name, block.input, user_id, get_matches)
                results.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": json.dumps(output),
                    }
                )
        messages.append({"role": "user", "content": results})

    return "Sorry, I could not finish that. Please try again."
